module PString = struct
  type t = string
  (** The p_string's underlying type. Although this is often represented with a
      string this should only contain alphanumeric characters and the period
      character. *)

  (** The default comparator. *)
  let compare = compare
end

module PStringMap = Map.Make (PString)

type code_block = {
  kernel : string;
  args : string list;
  code_segment : string;
}

type preamble = {
  strings : string PStringMap.t;
  lists : string list PStringMap.t;
}

type greek_letter =
  | Alpha
  | Beta
  | Gamma
  | Delta
  | Epsilon
  | Theta
  | Lambda
  | Mu
  | Pi
  | Sigma
  | Phi
  | Omega
  | GammaU
  | DeltaU
  | ThetaU
  | LambdaU
  | PiU
  | SigmaU
  | PhiU
  | OmegaU

type math_operator =
  | Equals
  | Plus
  | Minus
  | Neq
  | Less
  | Greater
  | Leq
  | Geq

type character =
  | Lparen
  | Rparen
  | Bar

type atomic =
  | Number of string
  | Greek of greek_letter
  | Variable of string
  | Operator of math_operator
  | Char of character

type math_expression =
  | Atomic of atomic
  | Power of math_expression * math_expression
  | Subscript of math_expression * math_expression
  | Sum of math_expression * math_expression * math_expression
  | Prod of math_expression * math_expression * math_expression
  | Frac of math_expression * math_expression
  | Sqrt of math_expression
  | Integral of math_expression * math_expression * math_expression
  | Compound of math_expression list

type description_fragment =
  | Text of string
  | InlineMathExpr of math_expression
  | BlockMathExpr of math_expression
  | Section of string
  | SubSection of string
  | Bold of description_fragment
  | Italic of description_fragment
  | Underline of description_fragment
  | Link of string * string
  | Codeblock of string * string

type ast_node =
  | PreambleNode of preamble
  | DescriptionNode of description_fragment
  | CodeBlockNode of code_block

type program = ast_node list
