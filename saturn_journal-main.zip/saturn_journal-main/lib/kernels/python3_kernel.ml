open Ast
open Kernel

module PyKernel : Kernel = struct
  exception RuntimeError of string

  let name = "python3"
  let codemirror = "Python 3"

  let validate_py_out out_list =
    if out_list |> List.length > 2 then
      (false, "python.out must specify at most two elements.")
    else if
      not
      @@ List.for_all
           (fun el -> List.exists (( = ) el) [ "stdout"; "stderr" ])
           out_list
    then (false, "python.out may only contain stdout or stderr.")
    else if 0 <> List.compare_lengths out_list (List.sort_uniq compare out_list)
    then (false, "python.out may not contain duplicate elements.")
    else (true, "")

  let assert_env { strings; lists } =
    let is_valid, err =
      if PStringMap.mem "python.out" strings then
        (false, "python.out parameter must be a p.string list.")
      else if PStringMap.mem "python.out" lists then
        let out_lst = PStringMap.find "python.out" lists in
        validate_py_out out_lst
      else (true, "")
    in
    (is_valid, err, "python3 --version")

  let eval { strings; lists } (code_block_lst : code_block list) :
      description_fragment list list Lwt.t =
    let long_rand_hack_string =
      "GLX_DELIMETER_PYTHON_KERNEL!!!_"
      ^ (Random.int 1073741823 |> string_of_int)
    in
    List.iter
      (fun { args; code_segment } ->
        let is_valid, hint = validate_py_out args in
        if not is_valid then
          raise
          @@ RuntimeError
               ("Error validating Python codeblock p.string:\n\
                 Expected: p.string.args = [?stdout, ?stderr]\n\
                 Got: p.string.args = [" ^ String.concat ", " args ^ "]\nHint: "
              ^ hint))
      code_block_lst;
    let has_out_stream map property args =
      if args = [] then
        if PStringMap.mem "python.out" map then
          let prop_list = PStringMap.find "python.out" map in
          List.exists (( = ) property) prop_list
        else true
      else List.exists (( = ) property) args
    in
    if
      PStringMap.mem "python.out" strings
      && PStringMap.find "python.out" strings = "global"
    then
      let global_file =
        List.fold_left
          (fun prev { args; code_segment } ->
            prev ^ "\nprint(\"" ^ long_rand_hack_string ^ "\")\neprint(\""
            ^ long_rand_hack_string ^ "\")\n" ^ code_segment)
          "" code_block_lst
      in
      let%lwt out, err =
        eval_temp_file global_file ".py" codemirror "python3"
      in
      let split_out = BatString.split_on_string ~by:long_rand_hack_string out in
      let split_err = BatString.split_on_string ~by:long_rand_hack_string err in
      let code_block_out = List.combine split_out split_err in
      let code_segments_joined =
        List.combine
          (List.map (fun { args; code_segment } -> code_segment) code_block_lst)
          code_block_out
      in
      Lwt.return
      @@ List.map
           (fun (segment, (out, err)) ->
             [ Codeblock (codemirror, segment) ]
             @ (if has_out_stream lists "stdout" [] then [ Text out ] else [])
             @ if has_out_stream lists "stderr" [] then [ Text err ] else [])
           code_segments_joined
    else
      let result =
        List.map
          (fun { args; code_segment } ->
            let%lwt out, err =
              eval_temp_file code_segment ".py" codemirror "python3"
            in
            let std_stream =
              if has_out_stream lists "stdout" args then [ Text out ] else []
            in
            let err_stream =
              if has_out_stream lists "stderr" args then [ Text err ] else []
            in
            Lwt.return
            @@ [ Codeblock (codemirror, code_segment) ]
            @ std_stream @ err_stream)
          code_block_lst
      in
      Lwt.all result
end
