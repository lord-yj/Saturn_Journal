open Kernel
open Ast

module TSYarnKernel : Kernel = struct
  exception RuntimeError of string

  let name = "js.yarn"
  let codemirror = "javascript"

  let assert_env { strings; lists } =
    let valid, error =
      if PStringMap.mem "js.yarn.stderr" lists then
        ( false,
          "Error validating js.yarn.stderr:\n\
           ts.yarn.stderr should be a p.string." )
      else if PStringMap.mem "js.yarn.stderr" strings then
        let v = PStringMap.find "js.yarn.stderr" strings in
        if v <> "true" && v <> "false" then
          ( false,
            "Error validating js.yarn.stderr\n\
             js.yarn.stderr must be one of true or false." )
        else (true, "")
      else (true, "")
    in
    (valid, error, "yarn --version")

  let eval { strings; lists } codeblocks =
    let dont_save_err =
      PStringMap.mem "js.yarn.stderr" strings
      && PStringMap.find "js.yarn.stderr" strings = "false"
    in
    Lwt.all
    @@ List.map
         (fun { args; code_segment } ->
           let%lwt stdout, stderr =
             eval_temp_file code_segment ".mjs" "JS Yarn" "node"
           in
           Lwt.return
           @@ [ Codeblock (codemirror, code_segment) ]
           @ [ Text stdout ]
           @ if dont_save_err then [] else [ Text stderr ])
         codeblocks
end
