open Kernel
open Ast

(** This is a kernel for the Elixir functional programming language (which has
    better concurrency than OCaml imo). You may specify the code execution
    scheme in the preamble. The default scheme is global. It should be
    represented as elixir.scheme = global | isolated. Global mode means each
    chunk of elixir is executed after the previous and concatenated into a
    harness module. Isolated means to execute each code block in its own harness
    module completely independently of the rest. In addition you may specify
    elixir.out = \[stdout, stderr\]. This array specifies the order in which the
    output of your elixir code is displayed by the GLX kernel. If you omit an
    argument for elixir.out, all output streams will be rendered for that code
    block. You may override this on an individual basis for each code-block in
    its p_string list iff elixir.scheme = isolated. By default the output is
    returned in the order stated above. Each code block's output preceeds the
    previous ones. **)
module ElixirKernel : Kernel = struct
  exception RuntimeError of string

  let valid_out_options = [ "stdout"; "stderr" ]
  let is_uniq lst = 0 = List.compare_lengths lst @@ List.sort_uniq compare lst
  let name = "elixir"

  let validate_output lst =
    if List.length lst > 2 then
      (false, "Elixir kernel expects p_string list with size no more than 2.")
    else if not @@ is_uniq lst then
      (false, "Elixir kernel expects unique p_string list.")
    else if
      not
      @@ List.for_all
           (fun name -> List.exists (( = ) name) valid_out_options)
           lst
    then
      ( false,
        "Elixir kernel expects p_string list to only contain stdout or stderr"
      )
    else (true, "")

  let assert_env { strings; lists } =
    let valid, error =
      if
        PStringMap.mem "elixir.scheme" strings
        && PStringMap.find "elixir.scheme" strings <> "global"
        && PStringMap.find "elixir.scheme" strings <> "isolated"
      then
        ( false,
          "Error validating elixir.scheme:\n\
           Expected: elixir.scheme = global | isolated\n\
           Got: elixir.scheme = "
          ^ PStringMap.find "elixir.scheme" strings )
      else if PStringMap.mem "elixir.out" strings then
        ( false,
          "Error validating elixir.out:\n\
           Expected: elixir.out = [?stdout, ?stderr]\n\
           Got: elixir.out = p.string\n\
           Hint: elixir.out should be a list." )
      else if PStringMap.mem "elixir.scheme" lists then
        ( false,
          "Error validating elixir.scheme:\n\
           Expected: elixir.out = p.string\n\
           Got: elixir.scheme = p.string list\n\
           Hint: elixir.scheme should be a p.string." )
      else if PStringMap.mem "elixir.out" lists then
        let is_valid, msg =
          validate_output (PStringMap.find "elixir.out" lists)
        in
        if not is_valid then
          ( false,
            "Error validating elixir.out:\n\
             Expected: elixir.out = [?stdout, ?stderr]\n\
             Got: elixir.out = ["
            ^ (PStringMap.find "elixir.out" lists |> String.concat ", ")
            ^ "]\nHint: " ^ msg )
        else (true, "")
      else (true, "")
    in
    (valid, error, "elixir -v")

  let codemirror = "Elixir"

  let eval { strings; lists } codeblocks =
    let long_rand_hack_string =
      "GLX_DELIMETER_ELIXIR_KERNEL!!!_"
      ^ (Random.int 1073741823 |> string_of_int)
    in
    List.iter
      (fun { args; code_segment } ->
        let is_valid, hint = validate_output args in
        if not is_valid then
          raise
          @@ RuntimeError
               ("Error validating Elixir codeblock p.string:\n\
                 Expected: p.string.args = [?stdout, ?stderr]\n\
                 Got: p.string.args = [" ^ String.concat ", " args ^ "]\nHint: "
              ^ hint))
      codeblocks;
    let has_out_stream map property args =
      if args = [] then
        if PStringMap.mem "elixir.out" map then
          let prop_list = PStringMap.find "elixir.out" map in
          List.exists (( = ) property) prop_list
        else true
      else List.exists (( = ) property) args
    in
    if
      PStringMap.mem "elixir.out" strings
      && PStringMap.find "elixir.out" strings = "global"
    then
      let global_file =
        List.fold_left
          (fun prev { args; code_segment } ->
            prev ^ "\nIO.puts \"" ^ long_rand_hack_string
            ^ "\"\nIO.puts :stderr, \"" ^ long_rand_hack_string ^ "\"\n"
            ^ code_segment)
          "" codeblocks
      in
      let%lwt out, err = eval_temp_file global_file ".exs" "Elixir" "elixir" in
      let split_out = BatString.split_on_string ~by:long_rand_hack_string out in
      let split_err = BatString.split_on_string ~by:long_rand_hack_string err in
      let code_block_out = List.combine split_out split_err in
      let code_segments_joined =
        List.combine
          (List.map (fun { args; code_segment } -> code_segment) codeblocks)
          code_block_out
      in
      Lwt.return
      @@ List.map
           (fun (segment, (out, err)) ->
             [ Codeblock (codemirror, segment) ]
             @ (if has_out_stream lists "stdout" [] then [ Text out ] else [])
             @ if has_out_stream lists "stderr" [] then [ Text err ] else [])
           code_segments_joined
    else
      let result =
        List.map
          (fun { args; code_segment } ->
            let%lwt out, err =
              eval_temp_file code_segment ".exs" "Elixir" "elixir"
            in
            let std_stream =
              if has_out_stream lists "stdout" args then [ Text out ] else []
            in
            let err_stream =
              if has_out_stream lists "stderr" args then [ Text err ] else []
            in
            Lwt.return
            @@ [ Codeblock (codemirror, code_segment) ]
            @ std_stream @ err_stream)
          codeblocks
      in
      Lwt.all result
end
