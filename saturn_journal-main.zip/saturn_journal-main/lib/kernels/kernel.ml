open Ast

module type Kernel = sig
  exception RuntimeError of string
  (** Thrown if the kernel if it encounters some runtime error trying to
      evaluate the user's code. *)

  val name : string
  (** The kernel's name, this name is used to import it into a GLX file. *)

  val assert_env : preamble -> bool * string * string
  (** Asserts that the platform (Linux etc.) has the required language's tools
      and that the preamble satisfies all of the Kernel's constraints. The first
      boolean represents whether the environment is valid, the second string is
      an error message of the environment is not valid. The third argument is a
      verifier command to run, which should check if a language's tools are
      locally available. *)

  val eval : preamble -> code_block list -> description_fragment list list Lwt.t
  (** Simplify a code segment to description fragments. Note: the length of the
      output produced by eval should be the same as the length of the input code
      block list. *)

  val codemirror : string
  (** The config for the codemirror code display. I still need to figure this
      out so just set it to something random. *)
end

(** [eval_temp_file code file_extension kernel_display_name cmd_name] is the
    evaluated stdout and stderr streams prodiced by executing code with
    [cmd_name]. *)
let eval_temp_file ex_code extension kernel_name cmd_name =
  let%lwt source_code, source_channel =
    Lwt_io.open_temp_file ~prefix:"glx_" ~suffix:extension ()
  in
  let%lwt stdout_name, stdout_channel =
    Lwt_io.open_temp_file ~prefix:"glx_stdout_" ~suffix:".dat" ()
  in
  let%lwt stderr_name, stderr_channel =
    Lwt_io.open_temp_file ~prefix:"glx_stderr_" ~suffix:".dat" ()
  in
  let%lwt () =
    Lwt_io.write_lines source_channel
      (String.split_on_char '\n' ex_code |> Lwt_stream.of_list)
  in
  let%lwt () = Lwt_io.close stdout_channel in
  let%lwt () = Lwt_io.close stderr_channel in
  let%lwt () = Lwt_io.close source_channel in
  let cmd_shell = Lwt_process.shell @@ cmd_name ^ " " ^ source_code in
  let%lwt exit_code =
    Lwt_process.exec ~timeout:5.0
      ~stdout:(`FD_copy (Unix.openfile stdout_name [ O_RDWR ] 666))
      ~stderr:(`FD_copy (Unix.openfile stderr_name [ O_RDWR ] 666))
      cmd_shell
  in
  let get_proc_code = function
    | Unix.WEXITED a -> "Exited: " ^ string_of_int a
    | Unix.WSIGNALED a -> "Signaled: " ^ string_of_int a
    | Unix.WSTOPPED a -> "Stopped: " ^ string_of_int a
  in
  let%lwt () =
    if exit_code <> WEXITED 0 then
      Lwt_io.print
        (kernel_name ^ " kernel: " ^ kernel_name
       ^ " code runner returned non-zero code: " ^ get_proc_code exit_code
       ^ "\n")
    else Lwt.return_unit
  in
  let read_file_str fname =
    let%lwt input = Lwt_io.open_file ~mode:Input fname in
    let%lwt data = Lwt_io.read_lines input |> Lwt_stream.to_list in
    let%lwt () = Lwt_io.close input in
    let%lwt () = Lwt_unix.unlink fname in
    Lwt.return @@ String.concat "\n" data
  in
  let%lwt stderr_val = read_file_str stderr_name in
  let%lwt stdout_val = read_file_str stdout_name in
  Lwt.return (stdout_val, stderr_val)
