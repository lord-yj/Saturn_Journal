open Ast

let lex_buffer lexbuf =
  let[@tail_mod_cons] rec loop () =
    match Lexer.read_document lexbuf with
    | Parser.EOF -> []
    | token -> token :: loop ()
  in
  loop ()

let lex s =
  let lexbuf = Lexing.from_string s in
  lex_buffer lexbuf

let parse (s : string) : Ast.program =
  let lexbuf = Lexing.from_string s in
  let ast = Parser.prog Lexer.read_document lexbuf in
  ast

let lex_buffer_math lexbuf =
  let[@tail_mod_cons] rec loop () =
    match Mathlexer.read_math lexbuf with
    | Mathparser.EOF -> []
    | token -> token :: loop ()
  in
  loop ()

let lex_math (s : string) : Mathparser.token list =
  let lexbuf = Lexing.from_string s in
  lex_buffer_math lexbuf

let parse_math (s : string) : Ast.math_expression =
  let lexbuf = Lexing.from_string s in
  let ast = Mathparser.math_expression_prog Mathlexer.read_math lexbuf in
  ast

let show_token = function
  | Parser.TEXT s -> Printf.sprintf "TEXT(%s)" s
  | Parser.SECTION -> "SECTION"
  | Parser.BEGIN -> "BEGIN"
  | Parser.END -> "END"
  | Parser.EOF -> "EOF"
  | Parser.BEGIN_LIST -> "BEGIN_LIST"
  | Parser.END_LIST -> "END_LIST"
  | Parser.PREAMBLE s -> Printf.sprintf "PREAMBLE(%s)" s
  | Parser.MATHBLOCK s -> Printf.sprintf "MATHBLOCK(%s)" s
  | Parser.INLINE s -> Printf.sprintf "INLINE(%s)" s
  | Parser.LINK -> "LINK"
  | Parser.OPEN_KEY -> "OPEN_KEY"
  | Parser.UNDERLINE -> "UNDERLINE"
  | Parser.ITALIC -> "ITALIC"
  | Parser.BOLD -> "BOLD"
  | Parser.SUBSECTION -> "SUBSECTION"
  | Parser.NEWLINE -> "NEWLINE"

let show_math_token = function
  | Mathparser.INT s -> Printf.sprintf "INT(%s)" s
  | Mathparser.EQUALS -> "EQUALS"
  | Mathparser.LESS -> "LESS"
  | Mathparser.GREATER -> "GREATER"
  | Mathparser.PLUS -> "PLUS"
  | Mathparser.MINUS -> "MINUS"
  | Mathparser.LPAREN -> "LPAREN"
  | Mathparser.RPAREN -> "RPAREN"
  | Mathparser.POWER -> "POWER"
  | Mathparser.SUBSCRIPT -> "SUBSCRIPT"
  | Mathparser.SUM_START -> "SUM_START"
  | Mathparser.PROD_START -> "PROD_START"
  | Mathparser.SQRT -> "SQRT"
  | Mathparser.FRAC -> "FRAC"
  | Mathparser.INTEGRAL -> "INTEGRAL"
  | Mathparser.OPEN_KEY -> "OPEN_KEY"
  | Mathparser.CLOSE_KEY -> "CLOSE_KEY"
  | Mathparser.EOF -> "EOF"
  | Mathparser.VAR s -> Printf.sprintf "VAR(%s)" s
  | Mathparser.ALPHA -> "ALPHA"
  | Mathparser.BETA -> "BETA"
  | Mathparser.GAMMA -> "GAMMA"
  | Mathparser.DELTA -> "DELTA"
  | Mathparser.EPSILON -> "EPSILON"
  | Mathparser.THETA -> "THETA"
  | Mathparser.LAMBDA -> "LAMBDA"
  | Mathparser.MU -> "MU"
  | Mathparser.PI -> "PI"
  | Mathparser.SIGMA -> "SIGMA"
  | Mathparser.PHI -> "PHI"
  | Mathparser.OMEGA -> "OMEGA"
  | Mathparser.GAMMAU -> "GAMMAU"
  | Mathparser.DELTAU -> "DELTAU"
  | Mathparser.THETAU -> "THETAU"
  | Mathparser.LAMBDAU -> "LAMBDAU"
  | Mathparser.PIU -> "PIU"
  | Mathparser.SIGMAU -> "SIGMAU"
  | Mathparser.PHIU -> "PHIU"
  | Mathparser.OMEGAU -> "OMEGAU"
  | Mathparser.BAR -> "BAR"
  | Mathparser.LEQ -> "LEQ"
  | Mathparser.GEQ -> "GEQ"
  | Mathparser.NEQ -> "NEQ"

let print_lexing (lst : Parser.token list) =
  let string_lst = List.map (fun a -> show_token a) lst in
  String.concat "; " string_lst

let print_math_lexing (lst : Mathparser.token list) =
  let string_lst = List.map (fun a -> show_math_token a) lst in
  String.concat "; " string_lst

(* This mutually recursive printing function is Adapted from ChatGPT, accessed
   12-10-2022. The prompt was "based on the Ast type file, write a printing
   function that prints the variant name and its contents."*)
let rec print_ast_nodes (nodes : ast_node list) : string =
  String.concat "\n" (List.map print_ast_node nodes)

and print_ast_node (node : ast_node) : string =
  match node with
  | PreambleNode preamble -> "PreambleNode: " ^ print_preamble preamble
  | DescriptionNode desc ->
      "DescriptionNode: " ^ print_description_fragment desc
  | CodeBlockNode code_block -> "CodeBlockNode: " ^ print_code_block code_block

and print_preamble (preamble : preamble) : string =
  let strings =
    PStringMap.bindings preamble.strings
    |> List.map (fun (k, v) -> Printf.sprintf "%s = %s" k v)
    |> String.concat "; "
  in
  let lists =
    PStringMap.bindings preamble.lists
    |> List.map (fun (k, v) ->
           Printf.sprintf "%s = [%s]" k (String.concat ", " v))
    |> String.concat "; "
  in
  Printf.sprintf "{ strings = { %s }; lists = { %s } }" strings lists

and print_description_fragment (desc : description_fragment) : string =
  match desc with
  | Text text -> Printf.sprintf "Text(%s)" text
  | InlineMathExpr expr ->
      Printf.sprintf "InlineMathExpr(%s)" (print_math_expression expr)
  | BlockMathExpr expr ->
      Printf.sprintf "BlockMathExpr(%s)" (print_math_expression expr)
  | Section title -> Printf.sprintf "Section(%s)" title
  | SubSection title -> Printf.sprintf "SubSection(%s)" title
  | Bold frag -> Printf.sprintf "Bold(%s)" (print_description_fragment frag)
  | Italic frag -> Printf.sprintf "Italic(%s)" (print_description_fragment frag)
  | Underline frag ->
      Printf.sprintf "Underline(%s)" (print_description_fragment frag)
  | Link (text, url) -> Printf.sprintf "Link(%s, %s)" text url
  | Codeblock (lang, code) -> Printf.sprintf "Codeblock(%s, %s)" lang code

and print_math_expression (expr : math_expression) : string =
  match expr with
  | Atomic atom -> print_atomic atom
  | Power (base, exp) ->
      Printf.sprintf "Power(%s, %s)"
        (print_math_expression base)
        (print_math_expression exp)
  | Subscript (base, sub) ->
      Printf.sprintf "Subscript(%s, %s)"
        (print_math_expression base)
        (print_math_expression sub)
  | Sum (lower, upper, body) ->
      Printf.sprintf "Sum(%s, %s, %s)"
        (print_math_expression lower)
        (print_math_expression upper)
        (print_math_expression body)
  | Prod (lower, upper, body) ->
      Printf.sprintf "Prod(%s, %s, %s)"
        (print_math_expression lower)
        (print_math_expression upper)
        (print_math_expression body)
  | Frac (num, denom) ->
      Printf.sprintf "Frac(%s, %s)"
        (print_math_expression num)
        (print_math_expression denom)
  | Sqrt expr -> Printf.sprintf "Sqrt(%s)" (print_math_expression expr)
  | Integral (lower, upper, body) ->
      Printf.sprintf "Integral(%s, %s, %s)"
        (print_math_expression lower)
        (print_math_expression upper)
        (print_math_expression body)
  | Compound exprs ->
      Printf.sprintf "Compound[%s]"
        (String.concat ", " (List.map print_math_expression exprs))

and print_atomic (atom : atomic) : string =
  match atom with
  | Number n -> Printf.sprintf "Number(%s)" n
  | Greek letter -> Printf.sprintf "Greek(%s)" (print_greek_letter letter)
  | Variable v -> Printf.sprintf "Variable(%s)" v
  | Operator op -> Printf.sprintf "Operator(%s)" (print_math_operator op)
  | Char c -> Printf.sprintf "Char(%s)" (print_character c)

and print_greek_letter (letter : greek_letter) : string =
  match letter with
  | Alpha -> "Alpha"
  | Beta -> "Beta"
  | Gamma -> "Gamma"
  | Delta -> "Delta"
  | Epsilon -> "Epsilon"
  | Theta -> "Theta"
  | Lambda -> "Lambda"
  | Mu -> "Mu"
  | Pi -> "Pi"
  | Sigma -> "Sigma"
  | Phi -> "Phi"
  | Omega -> "Omega"
  | GammaU -> "GammaU"
  | DeltaU -> "DeltaU"
  | ThetaU -> "ThetaU"
  | LambdaU -> "LambdaU"
  | PiU -> "PiU"
  | SigmaU -> "SigmaU"
  | PhiU -> "PhiU"
  | OmegaU -> "OmegaU"

and print_math_operator (op : math_operator) : string =
  match op with
  | Equals -> "Equals"
  | Plus -> "Plus"
  | Minus -> "Minus"
  | Neq -> "Neq"
  | Less -> "Less"
  | Greater -> "Greater"
  | Leq -> "Leq"
  | Geq -> "Geq"

and print_character (c : character) : string =
  match c with
  | Lparen -> "Lparen"
  | Rparen -> "Rparen"
  | Bar -> "Bar"

and print_code_block (code_block : code_block) : string =
  Printf.sprintf "{ kernel = %s; args = [%s]; code_segment = %s }"
    code_block.kernel
    (String.concat ", " code_block.args)
    code_block.code_segment
