open Ast

(* This preamble parsing function is Adapted from ChatGPT, accessed 12-10-2022.
   The prompt was "generate a function that parses a preamble string into the
   preamble type."*)
let parse_preamble input =
  let input =
    if String.sub input 0 4 = "\\glx" then
      String.sub input 5 (String.length input - 6)
    else input
  in
  let lines =
    String.split_on_char '\n' input |> List.filter (fun s -> s <> "")
  in
  let strings = ref PStringMap.empty in
  let lists = ref PStringMap.empty in

  let parse_line line =
    let line = String.trim line in
    match String.index_opt line '=' with
    | Some idx ->
        let key = String.sub line 0 idx |> String.trim in
        let value =
          String.sub line (idx + 1) (String.length line - idx - 1)
          |> String.trim
        in
        let value =
          if String.ends_with ~suffix:"," value then
            String.sub value 0 (String.length value - 1)
          else value
        in
        if
          String.starts_with ~prefix:"[" value
          && String.ends_with ~suffix:"]" value
        then
          let list_items =
            String.sub value 1 (String.length value - 2)
            |> String.split_on_char ',' |> List.map String.trim
          in
          lists := PStringMap.add key list_items !lists
        else strings := PStringMap.add key value !strings
    | None -> failwith ("Invalid line format: " ^ line)
  in

  List.iter parse_line lines;
  { strings = !strings; lists = !lists }

let parse_codeblock_args s =
  let list = String.split_on_char ',' s in
  List.map (fun a -> String.trim a) list

let unwrap_description = function
  | DescriptionNode d -> d
  | _ -> failwith "Expected DescriptionNode"
