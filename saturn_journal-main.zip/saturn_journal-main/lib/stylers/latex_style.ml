open Ast

module LatexStyle = Default_style.StylerWithMath (struct
  open Default_style.DefaultStyler

  let name = "latex.mathjx"
  let template = Styler.from_template "data/stylers/mathjax.html"
  let mk_text = Styler.sanitize

  let render_greek = function
    | Alpha -> "\\alpha"
    | Beta -> "\\beta"
    | Gamma -> "\\gamma"
    | Delta -> "\\delta"
    | Epsilon -> "\\epsilon"
    | Theta -> "\\theta"
    | Lambda -> "\\lambda"
    | Mu -> "\\mu"
    | Pi -> "\\pi"
    | Sigma -> "\\sigma"
    | Phi -> "\\phi"
    | Omega -> "\\omega"
    | GammaU -> "\\Gamma"
    | DeltaU -> "\\Delta"
    | ThetaU -> "\\Theta"
    | LambdaU -> "\\Lambda"
    | PiU -> "\\Pi"
    | SigmaU -> "\\Sigma"
    | PhiU -> "\\Phi"
    | OmegaU -> "\\Omega"

  let render_operator = function
    | Equals -> "="
    | Plus -> "+"
    | Minus -> "-"
    | Neq -> "\\neq"
    | Less -> "&lt;"
    | Greater -> "&gt;"
    | Leq -> "\\leq"
    | Geq -> "\\geq"

  let render_char = function
    | Lparen -> "("
    | Rparen -> ")"
    | Bar -> "|"

  let render_atomic = function
    | Number n -> n
    | Greek l -> "{" ^ render_greek l ^ "}"
    | Variable v -> "{" ^ mk_text v ^ "}"
    | Operator o -> render_operator o
    | Char c -> render_char c

  let rec render_math_i = function
    | Atomic a -> render_atomic a
    | Power (x, y) ->
        let rendered_x = render_math_i x in
        let rendered_y = render_math_i y in
        rendered_x ^ "^{" ^ rendered_y ^ "}"
    | Subscript (x, y) ->
        let rendered_x = render_math_i x in
        let rendered_y = render_math_i y in
        rendered_x ^ "_{" ^ rendered_y ^ "}"
    | Sum (sub, sup, right) -> sum_prod_renderer "sum" sub sup right
    | Prod (sub, sup, right) -> sum_prod_renderer "prod" sub sup right
    | Frac (top, bottom) ->
        let rendered_top, rendered_bottom =
          (render_math_i top, render_math_i bottom)
        in
        "\\frac{" ^ rendered_top ^ "}{" ^ rendered_bottom ^ "}"
    | Sqrt exp ->
        let rendered = render_math_i exp in
        "\\sqrt{" ^ rendered ^ "}"
    | Integral (a, b, right) -> sum_prod_renderer "int" b a right
    | Compound exp_lst ->
        List.fold_left
          (fun acc exp -> acc ^ "{" ^ render_math_i exp ^ "}")
          "" exp_lst

  and sum_prod_renderer symb sub sup right =
    let sub, sup, right =
      (render_math_i sub, render_math_i sup, render_math_i right)
    in
    "\\" ^ symb ^ "^{" ^ sup ^ "}" ^ "_{" ^ sub ^ "} " ^ right

  let render_math = function
    | Default_style.Inline exp -> "\\(" ^ render_math_i exp ^ "\\)"
    | Default_style.Block exp -> "\\[" ^ render_math_i exp ^ "\\]"
end)
