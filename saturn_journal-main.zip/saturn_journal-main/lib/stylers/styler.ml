open Ast

module type Styler = sig
  val name : string
  val mk_html : description_fragment list -> string
end

let from_template from_file =
  try BatFile.lines_of from_file |> BatList.of_enum |> BatString.concat "\n"
  with _ -> "{{ROOT}}"

let template_inject template text =
  snd (BatString.replace ~str:template ~sub:"{{ROOT}}" ~by:text)

let sanitize text =
  let no_and = BatString.nreplace ~str:text ~sub:"&" ~by:"&amp;" in
  let no_lt = BatString.nreplace ~str:no_and ~sub:"<" ~by:"&lt;" in
  let no_gt = BatString.nreplace ~str:no_lt ~sub:">" ~by:"&gt;" in
  let no_quote = BatString.nreplace ~str:no_gt ~sub:"\"" ~by:"&quot;" in
  BatString.nreplace ~str:no_quote ~sub:"'" ~by:"&#39;"
