open Ast

(** A type for representing inline or non-inline math fragments. *)
type math_fragment =
  | Inline of math_expression
  | Block of math_expression

(** Construct a styler with math expression evaluator passed as a functor. **)
module StylerWithMath (MathEvaluator : sig
  val name : string
  val template : string
  val render_math : math_fragment -> string
end) : Styler.Styler = struct
  let name = MathEvaluator.name
  let template = MathEvaluator.template
  let newline = "<br>"
  let two_spaces = "&nbsp; "

  let mk_text str =
    let sanitized = Styler.sanitize str in
    let newline_inserted =
      BatString.nreplace ~str:sanitized ~sub:"\n" ~by:newline
    in
    BatString.nreplace ~str:newline_inserted ~sub:"  " ~by:two_spaces

  let mk_safe_element elem safe = "<" ^ elem ^ ">" ^ safe ^ "</" ^ elem ^ ">"

  let mk_styled style_list elems =
    "<div style=\"" ^ style_list ^ "\">" ^ elems ^ "</div>"

  let mk_section = mk_safe_element "h1"
  let mk_subsection = mk_safe_element "h2"

  let mk_bold =
    mk_styled
      "font-weight: bold; display: inline; margin-left: 4px; margin-right: 4px"

  let mk_underline =
    mk_styled
      "text-decoration: underline; display: inline; margin-left: 4px; \
       margin-right: 4px"

  let mk_italics =
    mk_styled
      "font-style: italic; display: inline; margin-left: 4px; margin-right: 4px"

  let mk_href url name = "<a href=\"" ^ url ^ "\">" ^ name ^ "</a>"
  let mk_codeblock lang contents = mk_safe_element "pre" (mk_text contents)

  let rec mk_html_i fragments =
    List.fold_left
      (fun acc fragment ->
        match fragment with
        | Text str -> acc ^ mk_text str
        | Bold frag -> acc ^ (frag :: [] |> mk_html_i |> mk_bold)
        | Italic frag -> acc ^ (frag :: [] |> mk_html_i |> mk_italics)
        | Underline frag -> acc ^ (frag :: [] |> mk_html_i |> mk_underline)
        | Section str -> acc ^ (mk_text str |> mk_section)
        | SubSection str -> acc ^ (mk_text str |> mk_subsection)
        | Link (url, name) ->
            let url_text = mk_text url in
            let name_text = mk_text name in
            acc ^ mk_href url_text name_text
        | Codeblock (lang, contents) -> acc ^ mk_codeblock lang contents
        | InlineMathExpr exp -> acc ^ MathEvaluator.render_math (Inline exp)
        | BlockMathExpr exp -> acc ^ MathEvaluator.render_math (Block exp))
      "" fragments

  let mk_html fragments = mk_html_i fragments |> Styler.template_inject template
end

module DefaultStyler = StylerWithMath (struct
  let name = "default"
  let template = Styler.from_template "data/stylers/generic.html"
  let mk_text = Styler.sanitize

  let mk_monospaced tag_name contents =
    "<" ^ tag_name ^ " style=\"font-family: monospace, monospace;\">" ^ contents
    ^ "</" ^ tag_name ^ ">"

  let mk_safe_element elem safe = "<" ^ elem ^ ">" ^ safe ^ "</" ^ elem ^ ">"

  (** I was unable to figure out a different way of encoding this information
      :(. *)
  let render_greek = function
    | Alpha -> "&alpha;"
    | Beta -> "&beta;"
    | Gamma -> "&gamma;"
    | Delta -> "&delta;"
    | Epsilon -> "&epsilon;"
    | Theta -> "&theta;"
    | Lambda -> "&lambda;"
    | Mu -> "&mu;"
    | Pi -> "&pi;"
    | Sigma -> "&sigma;"
    | Phi -> "&phi;"
    | Omega -> "&omega;"
    | GammaU -> "&Gamma;"
    | DeltaU -> "&Delta;"
    | ThetaU -> "&Theta;"
    | LambdaU -> "&Lambda;"
    | PiU -> "&Pi;"
    | SigmaU -> "&Sigma;"
    | PhiU -> "&Phi;"
    | OmegaU -> "&Omega;"

  let render_operator = function
    | Equals -> "="
    | Plus -> "+"
    | Minus -> "-"
    | Neq -> "&ne;"
    | Less -> "&lt;"
    | Greater -> "&gt;"
    | Leq -> "&le;"
    | Geq -> "&ge;"

  let render_char = function
    | Lparen -> "("
    | Rparen -> ")"
    | Bar -> "|"

  let render_atomic = function
    | Number n -> n
    | Greek l -> render_greek l
    | Variable v -> mk_text v
    | Operator o -> render_operator o
    | Char c -> render_char c

  let rec render_math_i = function
    | Atomic a -> render_atomic a
    | Power (x, y) ->
        let rendered_x = render_math_i x in
        let rendered_y = render_math_i y in
        rendered_x ^ mk_safe_element "sup" rendered_y
    | Subscript (x, y) ->
        let rendered_x = render_math_i x in
        let rendered_y = render_math_i y in
        rendered_x ^ mk_safe_element "sub" rendered_y
    | Sum (sub, sup, right) -> sum_prod_renderer sub sup right SigmaU
    | Prod (sub, sup, right) -> sum_prod_renderer sub sup right PiU
    | Frac (top, bottom) ->
        let rendered_top, rendered_bottom =
          (render_math_i top, render_math_i bottom)
        in
        mk_safe_element "sup" rendered_top
        ^ "&frasl;"
        ^ mk_safe_element "sub" rendered_bottom
    | Sqrt exp ->
        let rendered = render_math_i exp in
        "&radic;<span style=\"text-decoration:overline;\">&nbsp;" ^ rendered
        ^ "&nbsp;</span>"
    | Integral (a, b, right) ->
        let right = render_math_i right in
        let integral = "&int;" in
        let a, b = (render_math_i a, render_math_i b) in
        integral ^ mk_safe_element "sub" a ^ mk_safe_element "sup" b ^ right
    | Compound exp_lst ->
        List.fold_left (fun acc exp -> acc ^ render_math_i exp) "" exp_lst

  and sum_prod_renderer sub sup right symb =
    let rendered_right = render_math_i right in
    let left_sub = Subscript (Atomic (Greek symb), sub) in
    let rendered_left = render_math_i (Power (left_sub, sup)) in
    rendered_left ^ rendered_right

  let render_math = function
    | Inline exp -> mk_monospaced "span" (render_math_i exp)
    | Block exp -> mk_monospaced "div" (render_math_i exp)
end)
