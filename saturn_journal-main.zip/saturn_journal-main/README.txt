Griffin Carter - gfc46@cornell.edu
Ilya Strugatskiy - is368@cornell.edu
Davey Seeman - djs467@cornell.edu
Sergio Lopez - sal292@cornell.edu
Yafet Negash - yjn2@cornell.edu

To be able to use this program, first please follow the instructions in INSTALL.md in order to download the necessary packages

After that, you can enter these commands to run the code

dune exec bin/main.exe -- help
dune exec bin/main.exe -- create [file_path]
dune exec bin/main.exe -- open [file_path]