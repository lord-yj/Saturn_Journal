open OUnit2
open Glx

type token_test = {
  (* Test description *)
  descr : string;
  (* String in glx format *)
  glx : string;
  (* Expected list of tokens *)
  exp : Parser.token list;
}

(**[test_lexer t] creates a test for the token_test [t]*)
let test_document_lexer (t : token_test) =
  t.descr >:: fun _ ->
  let res = Frontend.lex t.glx in
  assert_equal t.exp res ~printer:Frontend.print_lexing

(** [str_of_file fname] is the string contents of a file. *)
let str_of_file fname =
  try fname |> BatFile.lines_of |> BatList.of_enum |> String.concat "\n"
  with _ -> failwith "Invalid file."

(* List of tests for the lexer*)
let test_lexer_list =
  List.map test_document_lexer
    [
      (* Comments *)
      { descr = "Simple comments"; glx = "%\n"; exp = [] };
      { descr = "Simple comments"; glx = "%Hi\n"; exp = [] };
      { descr = "Simple comments"; glx = "% Hi\n"; exp = [] };
      { descr = "Two/more comments"; glx = "%A\n%B\n"; exp = [] };
      { descr = "Two/more comments"; glx = "%    \n%\n%a\n"; exp = [] };
      (* Preamble *)
      {
        descr = "Simple Preamble";
        glx = "\\glx{\nversion = 1.0}";
        exp = [ PREAMBLE "\nversion = 1.0" ];
      };
      {
        descr = "Sample Preamble";
        glx =
          "\\glx{\n\
           version = 1.0,\n\
           style = light,\n\
           kernels = [python3, elixir]\n\
           }";
        exp =
          [
            PREAMBLE
              "\nversion = 1.0,\nstyle = light,\nkernels = [python3, elixir]\n";
          ];
      };
      (* Sections *)
      { descr = "Simple Section"; glx = "\\section{}"; exp = [ SECTION ] };
      {
        descr = "Simple Section";
        glx = "hi\\newline hello";
        exp = [ TEXT "hi"; NEWLINE; TEXT " hello" ];
      };
      {
        descr = "Simple Section";
        glx = "\\section{Hi}";
        exp = [ SECTION; TEXT "Hi" ];
      };
      {
        descr = "Multiple sections";
        glx = "\\section{Hello}\n%Comment\n\\section{World}Hi";
        exp = [ SECTION; TEXT "Hello"; SECTION; TEXT "World"; TEXT "Hi" ];
      };
      {
        descr = "Simple section";
        glx = "\\link{haha}{troll}";
        exp = [ LINK; TEXT "haha"; OPEN_KEY; TEXT "troll" ];
      };
      { descr = "Simple section"; glx = "{"; exp = [ OPEN_KEY ] };
      {
        descr = "Simple section";
        glx = "\\underline{haha}";
        exp = [ UNDERLINE; TEXT "haha" ];
      };
      {
        descr = "Simple section";
        glx = "\\textit{haha}\\textbf{haha}\\subsection{Hi}";
        exp = [ ITALIC; TEXT "haha"; BOLD; TEXT "haha"; SUBSECTION; TEXT "Hi" ];
      };
      (* Math expressions *)
      {
        descr = "Simple math inline";
        glx = "\\(1\\)";
        exp = [ INLINE "\\(1\\)" ];
      };
      {
        descr = "Complex math inline";
        glx = "\\(1+1=2\\)";
        exp = [ INLINE "\\(1+1=2\\)" ];
      };
      (* Code blocks *)
      {
        descr = "Sample codeblock";
        glx =
          "\\begin{python3}[stdout, stderr]\n\
           print(\"Hello, world!\")\n\
           print(\"Hi\")\n\
           \\end{python3}";
        exp =
          [
            BEGIN;
            TEXT "python3";
            BEGIN_LIST;
            TEXT "stdout, stderr";
            END_LIST;
            TEXT "print(\"Hello, world!\")";
            TEXT "print(\"Hi\")";
            END;
            TEXT "python3";
          ];
      };
      (* Full example *)
      {
        descr = "Full example";
        glx = str_of_file "../data/glx_examples/example_1.glx";
        exp =
          [
            PREAMBLE
              "\nversion = 1.0,\nstyle = light,\nkernels = [python3, elixir]\n";
            SECTION;
            TEXT "My First GLX Document";
            TEXT "This is my first GLX document.";
            TEXT "I can freely write text here with multiple spaces.";
            TEXT "I can also insert some fancy block (or inline) math:";
            MATHBLOCK "\\[\n\\sum_{i=1}^{n} x_i\n\\]";
            BEGIN;
            TEXT "python3";
            BEGIN_LIST;
            TEXT "stdout, stderr";
            END_LIST;
            TEXT "print(\"Hello, world!\")";
            END;
            TEXT "python3";
            BEGIN;
            TEXT "elixir";
            TEXT "IO.puts \"Elixir > Ocaml\"";
            END;
            TEXT "elixir";
          ];
      };
    ]

type math_token_test = {
  (* Test description *)
  descr : string;
  (* String in glx format *)
  glx : string;
  (* Expected list of tokens *)
  exp : Mathparser.token list;
}

let test_math_lexer (t : math_token_test) =
  t.descr >:: fun _ ->
  let res = Frontend.lex_math t.glx in
  assert_equal t.exp res ~printer:Frontend.print_math_lexing

let test_math_lexer_list =
  List.map test_math_lexer
    [
      {
        descr = "Simple math expressions";
        glx = "1+1 = 2";
        exp = [ INT "1"; PLUS; INT "1"; EQUALS; INT "2" ];
      };
      {
        descr = "Simple math expressions";
        glx =
          "< > - ( ) \\prod \\sqrt \\frac \\int \\alpha \\beta \\gamma \\delta \
           \\epsilon \\theta \\lambda \\mu \\pi \\sigma \\phi \\omega \\Gamma \
           \\Delta \\Theta \\Lambda \\Pi \\Sigma \\Phi \\Omega | \\leq \\geq \
           \\neq";
        exp =
          [
            LESS;
            GREATER;
            MINUS;
            LPAREN;
            RPAREN;
            PROD_START;
            SQRT;
            FRAC;
            INTEGRAL;
            ALPHA;
            BETA;
            GAMMA;
            DELTA;
            EPSILON;
            THETA;
            LAMBDA;
            MU;
            PI;
            SIGMA;
            PHI;
            OMEGA;
            GAMMAU;
            DELTAU;
            THETAU;
            LAMBDAU;
            PIU;
            SIGMAU;
            PHIU;
            OMEGAU;
            BAR;
            LEQ;
            GEQ;
            NEQ;
          ];
      };
      {
        descr = "Simple math expressions";
        glx = "\\int_{0}^1x";
        exp =
          [
            INTEGRAL;
            SUBSCRIPT;
            OPEN_KEY;
            INT "0";
            CLOSE_KEY;
            POWER;
            INT "1";
            VAR "x";
          ];
      };
      {
        descr = "Complex math expressions";
        glx = "\\sum_{i=1}^{n}x^2";
        exp =
          [
            SUM_START;
            SUBSCRIPT;
            OPEN_KEY;
            VAR "i";
            EQUALS;
            INT "1";
            CLOSE_KEY;
            POWER;
            OPEN_KEY;
            VAR "n";
            CLOSE_KEY;
            VAR "x";
            POWER;
            INT "2";
          ];
      };
    ]

type parser_test = {
  (* Test description *)
  descr : string;
  (* String in glx format *)
  glx : string;
  (* Expected list of tokens *)
  exp : string;
}

(**[test_lexer t] creates a test for the token_test [t]*)
let test_parser (t : parser_test) =
  t.descr >:: fun _ ->
  let res = Frontend.parse t.glx in
  assert_equal t.exp (Frontend.print_ast_nodes res) ~printer:(fun x -> x)

let test_parser_list =
  List.map test_parser
    [
      {
        descr = "Parsing complete example";
        glx = str_of_file "../data/glx_examples/example_2.glx";
        exp = str_of_file "../data/test_expected/expected_tokens1.txt";
      };
    ]

type parser_math_test = {
  (* Test description *)
  descr : string;
  (* String in glx format *)
  glx : string;
  (* Expected list of tokens *)
  exp : string;
}

(**[test_lexer t] creates a test for the token_test [t]*)
let test_parser_math (t : parser_math_test) =
  t.descr >:: fun _ ->
  let res = Frontend.parse_math t.glx in
  assert_equal t.exp
    (Frontend.print_ast_nodes [ DescriptionNode (BlockMathExpr res) ])
    ~printer:(fun x -> x)

let test_parser_math_list =
  List.map test_parser_math
    [
      {
        descr = "Simple math expressions";
        glx = "1+1 = 2";
        exp =
          "DescriptionNode: BlockMathExpr(Compound[Number(1), Operator(Plus), \
           Number(1), Operator(Equals), Number(2)])";
      };
      {
        descr = "Simple math expressions";
        glx = "\\sum_{i=1}^{n}x^2";
        exp =
          "DescriptionNode: BlockMathExpr(Sum(Compound[Variable(i), \
           Operator(Equals), Number(1)], Compound[Variable(n)], \
           Power(Variable(x), Number(2))))";
      };
      {
        descr = "Simple math expressions";
        glx = "\\frac{1\\leq 2}{2 \\geq 3}";
        exp =
          "DescriptionNode: BlockMathExpr(Frac(Compound[Number(1), \
           Operator(Leq), Number(2)], Compound[Number(2), Operator(Geq), \
           Number(3)]))";
      };
      {
        descr = "Simple math expressions";
        glx =
          "\\alpha \\beta \\gamma \\delta \\epsilon \\theta \\lambda \\mu \\pi \
           \\sigma \\phi \\omega \\Gamma \\Delta \\Theta \\Lambda \\Pi \\Sigma \
           \\Phi \\Omega";
        exp =
          "DescriptionNode: BlockMathExpr(Compound[Greek(Alpha), Greek(Beta), \
           Greek(Gamma), Greek(Delta), Greek(Epsilon), Greek(Theta), \
           Greek(Lambda), Greek(Mu), Greek(Pi), Greek(Sigma), Greek(Phi), \
           Greek(Omega), Greek(GammaU), Greek(DeltaU), Greek(ThetaU), \
           Greek(LambdaU), Greek(PiU), Greek(SigmaU), Greek(PhiU), \
           Greek(OmegaU)])";
      };
    ]

let tests =
  test_lexer_list @ test_math_lexer_list @ test_parser_list
  @ test_parser_math_list
