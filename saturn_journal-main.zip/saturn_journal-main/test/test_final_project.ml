open OUnit2
open Glx
open Glx.Elixir_kernel
open Glx.Ts_yarn_kernel
open Glx.Python3_kernel
open Ast
open OUnitLwt

(* This provides some end to end test cases of the entire parsing framework, and
   ensures that everything matches what it should, going from tokenizer all the
   way to html. The html was hand verified at the end of generation to ensure
   that it was compliant. *)

module TestSuite (K : Kernel.Kernel) = struct
  (* Parameterized test for assert_env *)
  let test_assert_env ~preamble expected_result _ =
    let actual_result, error_msg, verifier_cmd = K.assert_env preamble in
    assert_equal ~msg:error_msg expected_result actual_result;
    if actual_result then
      let exit_code = Sys.command verifier_cmd in
      if exit_code <> 0 then
        assert_failure
          ("Verifier command failed with exit code: " ^ string_of_int exit_code)

  (* Test eval: short-circuit if command fails, diff output if it succeeds *)
  let test_eval ~preamble ~code_blocks expected_outputs _ =
    try
      let verifier_cmd =
        match K.assert_env preamble with
        | true, _, cmd -> cmd
        | false, error_msg, _ -> raise (Failure error_msg)
      in
      let exit_code = Sys.command verifier_cmd in
      if exit_code <> 0 then
        Lwt_io.printf
          "Warning: Short-circuited test_eval due to failed verifier command.\n"
      else
        let%lwt results = K.eval preamble code_blocks in
        Lwt.return
        @@ assert_equal
             ~printer:(fun x ->
               List.map (fun el -> List.length el |> string_of_int) x
               |> String.concat "; ")
             expected_outputs results
    with Failure msg -> assert_failure ("Precondition failed: " ^ msg)

  let suite preamble assert_env_tests eval_tests =
    List.map
      (fun (desc, code_blocks, expected_outputs) ->
        "test_eval - " ^ desc
        >:: lwt_wrapper @@ test_eval ~preamble ~code_blocks expected_outputs)
      eval_tests
    @ List.map
        (fun (desc, expected_result, preamble) ->
          "test_assert_env - " ^ desc
          >:: test_assert_env ~preamble expected_result)
        assert_env_tests
end

let test_eval_temp_file _ =
  let ex_code = "print(\"Hello, World!\")" in
  let extension = ".py" in
  let kernel_name = "Python" in
  let cmd_name = "python3" in

  let%lwt result =
    Kernel.eval_temp_file ex_code extension kernel_name cmd_name
  in
  Lwt.return
  @@
  match result with
  | stdout_val, stderr_val ->
      assert_equal stdout_val "Hello, World!" ~msg:"Unexpected stdout."
        ~printer:Fun.id;
      assert_equal stderr_val "" ~msg:"Unexpected stderr." ~printer:Fun.id

module ElixirTestSuite = TestSuite (ElixirKernel)

let elixir_preamble =
  {
    strings = PStringMap.of_list [ ("elixir.scheme", "global") ];
    lists = PStringMap.of_list [ ("elixir.out", [ "stdout" ]) ];
  }

let elixir_assert_env_tests =
  [
    ("valid configuration", true, elixir_preamble);
    ( "invalid scheme",
      false,
      {
        strings = PStringMap.of_list [ ("elixir.scheme", "invalid") ];
        lists = PStringMap.empty;
      } );
    ( "invalid output list",
      false,
      {
        strings = PStringMap.empty;
        lists = PStringMap.of_list [ ("elixir.out", [ "invalid"; "stdout" ]) ];
      } );
  ]

let elixir_eval_tests =
  [
    ( "simple eval",
      [
        {
          kernel = "elixir";
          args = [ "stdout" ];
          code_segment = "IO.puts \"Hello, Elixir!\"";
        };
      ],
      [
        [
          Codeblock ("Elixir", "IO.puts \"Hello, Elixir!\"");
          Text "Hello, Elixir!";
        ];
      ] );
    ( "simple eval stderr",
      [
        {
          kernel = "elixir";
          args = [ "stderr" ];
          code_segment = "IO.puts :stderr, \"Hello, Elixir!\"";
        };
      ],
      [
        [
          Codeblock ("Elixir", "IO.puts :stderr, \"Hello, Elixir!\"");
          Text "Hello, Elixir!";
        ];
      ] );
  ]

module PyKernelTestSuite = TestSuite (PyKernel)
module TSYarnKernelTestSuite = TestSuite (TSYarnKernel)

let python3_preamble =
  {
    lists = PStringMap.of_list [ ("python.out", [ "stdout"; "stderr" ]) ];
    strings = PStringMap.empty;
  }

let python3_assert_env_tests =
  [
    ("valid configuration", true, python3_preamble);
    ( "invalid output configuration",
      false,
      {
        strings = PStringMap.of_list [ ("python.out", "invalid") ];
        lists = PStringMap.empty;
      } );
  ]

let python3_eval_tests =
  [
    ( "simple eval Python",
      [
        {
          kernel = "python3";
          args = [ "stdout" ];
          code_segment = "print(\"Hello, Python!\")";
        };
      ],
      [
        [
          Codeblock ("Python 3", "print(\"Hello, Python!\")");
          Text "Hello, Python!";
        ];
      ] );
    ( "simple eval Python stderr",
      [
        {
          kernel = "python3";
          args = [ "stdout" ];
          code_segment = "print(\"Hello, Python!\", file=sys.stderr)";
        };
      ],
      [
        [
          Codeblock ("Python 3", "print(\"Hello, Python!\", file=sys.stderr)");
          Text "";
        ];
      ] );
  ]

let js_yarn_preamble =
  {
    strings = PStringMap.of_list [ ("js.yarn.stderr", "false") ];
    lists = PStringMap.empty;
  }

let js_yarn_assert_env_tests =
  [
    ("valid configuration", true, js_yarn_preamble);
    ( "stderr disabled",
      true,
      {
        strings = PStringMap.of_list [ ("js.yarn.stderr", "false") ];
        lists = PStringMap.empty;
      } );
    ( "invalid configuration",
      false,
      {
        strings = PStringMap.of_list [ ("js.yarn.stderr", "invalid") ];
        lists = PStringMap.empty;
      } );
  ]

let js_yarn_eval_tests =
  [
    ( "simple eval JS",
      [
        {
          kernel = "js.yarn";
          args = [];
          code_segment = "console.log(\"Hello, JavaScript!\")";
        };
      ],
      [
        [
          Codeblock ("javascript", "console.log(\"Hello, JavaScript!\")");
          Text "Hello, JavaScript!";
        ];
      ] );
  ]

let tests =
  "GLX Lib Tests"
  >::: List.flatten
         [
           ElixirTestSuite.suite elixir_preamble elixir_assert_env_tests
             elixir_eval_tests;
           PyKernelTestSuite.suite python3_preamble python3_assert_env_tests
             python3_eval_tests;
           TSYarnKernelTestSuite.suite js_yarn_preamble js_yarn_assert_env_tests
             js_yarn_eval_tests;
           [ "test eval temp file" >:: lwt_wrapper test_eval_temp_file ];
           Test_parser.tests;
           Test_styler.tests;
         ]

let run_test = run_test_tt_main tests
