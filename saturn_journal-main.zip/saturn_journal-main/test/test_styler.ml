open OUnit2
open Glx

type token_test = {
  (* Test description *)
  descr : string;
  (*Description Fragment Tokens*)
  glx : string;
  (* Expected list of tokens *)
  exp : string;
}

(** [str_of_file fname] is the string contents of a file. *)
let str_of_file fname =
  try fname |> BatFile.lines_of |> BatList.of_enum |> String.concat "\n"
  with _ -> failwith "Invalid file."

let rec ast_to_des lst =
  match lst with
  |[] -> []
  |Ast.PreambleNode v :: t -> ast_to_des t
  |Ast.DescriptionNode v :: t -> v :: (ast_to_des t)
  |Ast.CodeBlockNode v :: t -> ast_to_des t

let test_default_styler (t : token_test) =
  t.descr >:: fun _ ->
  let res = Frontend.parse t.glx in
  let des = ast_to_des res in
  let html = Default_style.DefaultStyler.mk_html des in
  assert_equal t.exp html

let test_latex_styler (t : token_test) =
  t.descr >:: fun _ ->
  let res = Frontend.parse t.glx in
  let des = ast_to_des res in
  let html = Latex_style.LatexStyle.mk_html des in
  assert_equal t.exp html

let test_default_styler_list =
  List.map test_default_styler
    [
      {
        descr = "Test File 1";
        glx = str_of_file "../data/glx_examples/example_1_NC.glx";
        exp = str_of_file "../data/test_expected/expected_html_1.txt"
      };
      {
        descr = "Test File 2";
        glx = str_of_file "../data/glx_examples/example_2_NC.glx";
        exp = str_of_file "../data/test_expected/expected_html_2.txt"
      };
      {
      descr = "Test File 3";
      glx = str_of_file "../data/glx_examples/example_3_NC.glx";
      exp = str_of_file "../data/test_expected/expected_html_3.txt"
    };
    ]

let test_latex_styler_list =
  List.map test_latex_styler
    [
      {
        descr = "Test File 1";
        glx = str_of_file "../data/glx_examples/example_1_latex_NC.glx";
        exp = str_of_file "../data/test_expected/expected_html_latex_1.txt"
      };
      {
        descr = "Test File 2";
        glx = str_of_file "../data/glx_examples/example_2_latex_NC.glx";
        exp = str_of_file "../data/test_expected/expected_html_latex_2.txt"
      };
      {
      descr = "Test File 3";
      glx = str_of_file "../data/glx_examples/example_3_latex_NC.glx";
      exp = str_of_file "../data/test_expected/expected_html_latex_3.txt"
    };
    ]


let tests = test_default_styler_list @ test_latex_styler_list